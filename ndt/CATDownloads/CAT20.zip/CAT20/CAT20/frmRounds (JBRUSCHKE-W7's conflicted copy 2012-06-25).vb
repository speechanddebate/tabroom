﻿Public Class frmRounds
    Dim ds As New DataSet
    Private Sub frmRounds_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Load
        LoadFile(ds, "TourneyData")
        Call CheckForGoodToGo()

        'fill even cbo
        cboEvent.DataSource = ds.Tables("Event")
        cboEvent.ValueMember = "ID"
        cboEvent.DisplayMember = "EventName"
        cboEvent.Text = "Select Division"

        'eliminate null values
        For x = 0 To ds.Tables("Round").Rows.Count - 1
            If ds.Tables("Round").Rows(x).Item("PairingScheme") Is System.DBNull.Value Then ds.Tables("Round").Rows(x).Item("PairingScheme") = "None"
            If ds.Tables("Round").Rows(x).Item("Flight") Is System.DBNull.Value Then ds.Tables("Round").Rows(x).Item("Flight") = False
            If ds.Tables("Round").Rows(x).Item("TB_SET") Is System.DBNull.Value Then ds.Tables("Round").Rows(x).Item("TB_SET") = 1
            ds.Tables("Round").Rows(x).Item("JudgePlaceScheme") = ds.Tables("Round").Rows(x).Item("JudgePlaceScheme").trim
        Next

        'Link up the comboboxes that pull from other tables
        Dim dgvc2 As New DataGridViewComboBoxColumn
        dgvc2.DataSource = ds.Tables("Tiebreak_Set")
        dgvc2.ValueMember = "ID"
        dgvc2.DisplayMember = "TBSET_Name"
        dgvc2.DataPropertyName = "TB_SET"
        dgvc2.HeaderText = "Tiebreak Set"
        dgvc2.Name = "TB_SET"
        dgvc2.DisplayIndex = 2
        DataGridView1.Columns.Add(dgvc2)

        dgvc2 = New DataGridViewComboBoxColumn
        dgvc2.DataSource = ds.Tables("Timeslot")
        dgvc2.ValueMember = "ID"
        dgvc2.DisplayMember = "Name"
        dgvc2.DataPropertyName = "Timeslot"
        dgvc2.HeaderText = "TimeSlot"
        dgvc2.Name = "TimeSlot"
        dgvc2.DisplayIndex = 3
        DataGridView1.Columns.Add(dgvc2)

        DataGridView1.AutoGenerateColumns = False
        DataGridView1.DataSource = ds.Tables("Round")
        
    End Sub
    Sub CheckForGoodToGo()
        'check that divisions exist
        If ds.Tables("Event").Rows.Count = 0 Then
            MsgBox("You MUST set up divisions before you set up the rounds.  Please close this screen, return to the SET UP DIVISIONS screen, and then return to this page.", MsgBoxStyle.OkOnly)
        End If
        'check that timeslots exist
        If ds.Tables("TimeSlot").Rows.Count = 0 Then
            MsgBox("You MUST set up time slots before you set up the rounds.  Please close this screen, return to the ENTER TOURNAMENT-WIDE SETTINGS screen, and then return to this page.", MsgBoxStyle.OkOnly)
        End If
        'check for tiebreakers
        If ds.Tables("Tiebreak").Rows.Count = 0 Or ds.Tables("Tiebreak_Set").Rows.Count = 0 Then
            MsgBox("You MUST set up tiebreakers before you set up the rounds.  Please close this screen, return to the SET UP TIEBREAKERS screen, and then return to this page.", MsgBoxStyle.OkOnly)
        End If
        'scroll events and add rounds if none exist
        Dim fdRds As DataRow()
        For x = 0 To ds.Tables("Event").Rows.Count - 1
            fdRds = ds.Tables("Round").Select("Event=" & ds.Tables("Event").Rows(x).Item("ID"))
            If fdRds.Length = 0 Then Call MakeRoundsByDivision(ds.Tables("Event").Rows(x).Item("ID"))
        Next
    End Sub
    Sub eHandle() Handles DataGridView1.DataError
        MsgBox("Error at column" & DataGridView1.CurrentCell.ColumnIndex)
    End Sub
    Private Sub frmRounds_Unload(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
        Call SaveFile(DS)
        DS.Dispose()
    End Sub

    Private Sub ResetAllRounds_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butResetAllRounds.Click
        Dim q As Integer
        q = MsgBox("Do you want to delete all existing rounds?  The much safer option is to select NO; this will maintain all existing rounds but set up default values for all rounds that do not have them.  Selecting YES will delete all existing rounds for all divisions, in the process erasing all currently scheduled rounds and any results.  Selecting NO will simply add default values where they are missing.", MsgBoxStyle.YesNo)
        Dim x As Integer
        If q = vbYes Then
            For x = ds.Tables("round").Rows.Count - 1 To 0 Step -1
                ds.Tables("round").Rows(x).Delete()
            Next x
        End If

        For x = 0 To ds.Tables("Event").Rows.Count - 1
            Call MakeRoundsByDivision(ds.Tables("event").Rows(x).Item("ID"))
            Call MakeElimSeeds(ds.Tables("event").Rows(x).Item("ID"))
        Next x

        ds.Tables("ROUND").AcceptChanges()
        DataGridView1.DataSource = ds.Tables("Round")
    End Sub
    Sub MakeElimSeeds(ByVal eventID As Integer)
        'pull all elim rounds
        Dim drElimRds As DataRow()
        drElimRds = ds.Tables("Round").Select("Event=" & eventID & " and RD_NAME>9")
        Dim nSeeds, y As Integer
        Dim dr As DataRow
        For x = 0 To drElimRds.Length - 1
            nSeeds = 2 ^ (17 - drElimRds(x).Item("RD_NAME"))
            For y = 1 To nSeeds
                dr = ds.Tables("ELIMSEED").NewRow
                dr.Item("Event") = eventID
                dr.Item("Round") = drElimRds(x).Item("ID")
                dr.Item("Entry") = 0
                dr.Item("Seed") = y
                ds.Tables("ELIMSEED").Rows.Add(dr)
            Next y
        Next x
        ds.Tables("ELIMSEED").AcceptChanges()
    End Sub
    Sub MakeRoundsByDivision(ByVal EventID As Integer)
        Dim y, nprelims, nelims As Integer
        Dim dr As DataRow
        nprelims = getEventSetting(ds, ds.Tables("Event").Rows(0).Item("ID"), "nPrelims")
        nelims = getEventSetting(ds, ds.Tables("Event").Rows(0).Item("ID"), "nElims")
        Dim drEvent As DataRow
        drEvent = ds.Tables("Event").Rows.Find(EventID)
        Dim fdRows As DataRow()
        For y = 0 To nprelims - 1
            'see if round exists already; if not, add it.
            fdRows = ds.Tables("Round").Select("Rd_Name =" & y + 1)
            If fdRows.Length = 0 Then
                dr = ds.Tables("ROUND").NewRow
                dr.Item("EVENT") = drEvent.Item("ID")
                dr.Item("TIMESLOT") = ds.Tables("TIMESLOT").Rows(y).Item("ID")
                dr.Item("TB_SET") = 1
                dr.Item("FLIGHT") = False : If drEvent.Item("Type") = "Lincoln-Douglas" Then dr.Item("FLIGHT") = True
                dr.Item("RD_NAME") = y + 1
                dr.Item("JUDGESPERPANEL") = 1
                dr.Item("JudgePlaceScheme") = "Random"
                dr.Item("PairingScheme") = "HighLow"
                If Int(y / 3) <= y Then dr.Item("PairingScheme") = "Preset"
                dr.Item("LABEL") = "Preliminary round " & y + 1.ToString
                ds.Tables("ROUND").Rows.Add(dr)
            End If
        Next y
        For y = 16 To 16 - nelims Step -1
            fdRows = ds.Tables("Round").Select("Rd_Name = " & y + 1)
            If fdRows.Length = 0 Then
                dr = ds.Tables("ROUND").NewRow
                dr.Item("EVENT") = drEvent.Item("ID")
                dr.Item("TIMESLOT") = y : dr.Item("TB_SET") = 1
                dr.Item("FLIGHT") = False : If drEvent.Item("Type") = "Lincoln-Douglas" Then dr.Item("FLIGHT") = True
                dr.Item("RD_NAME") = y
                dr.Item("JUDGESPERPANEL") = 1
                dr.Item("JudgePlaceScheme") = "Random"
                dr.Item("PairingScheme") = "Elim"
                dr.Item("LABEL") = GetElimName(dr.Item("RD_NAME"))
                ds.Tables("ROUND").Rows.Add(dr)
            End If
        Next y
    End Sub
    Private Sub butShowDivision_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butShowDivision.Click
        If cboEvent.SelectedIndex = -1 Then
            MsgBox("Please select a division and try again.")
            Exit Sub
        End If
        Dim dtv As New DataView(ds.Tables("Round"))
        dtv.RowFilter = "Event=" & cboEvent.SelectedValue
        DataGridView1.DataSource = dtv
    End Sub

    Private Sub butShowAllDivisions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butShowAllDivisions.Click
        DataGridView1.DataSource = ds.Tables("Round")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        For x = 0 To ds.Tables("EVENT").Rows.Count - 1
            Call MakeElimSeeds(ds.Tables("Event").Rows(x).Item("ID"))
        Next
    End Sub
    Private Sub UserDeletingRow(ByVal sender As Object, ByVal e As DataGridViewRowCancelEventArgs) Handles DataGridView1.UserDeletingRow
        Dim drRound As DataRow : drRound = ds.Tables("Round").Rows.Find(DataGridView1.CurrentRow.Cells("ID").Value)
        Dim fdPanel As DataRow()
        fdPanel = ds.Tables("Panel").Select("Round=" & drRound.Item("ID"))
        If fdPanel.Length = 0 Then Exit Sub
        Dim q As Integer
        q = MsgBox("WARNING!  Pairings for this round have been detected.  Continuing with the delete will erase all pairings and results associated with this division!  Click OK to continue or CANCEL to continue without deleting.", MsgBoxStyle.OkCancel)
        If q = vbCancel Then e.Cancel = True
    End Sub
End Class