﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmShowPairings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.DataGridView2 = New System.Windows.Forms.DataGridView
        Me.butLoad = New System.Windows.Forms.Button
        Me.cboRound = New System.Windows.Forms.ComboBox
        Me.butDelete = New System.Windows.Forms.Button
        Me.butAdd = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.butDeleteRow = New System.Windows.Forms.Button
        Me.butAddPanel = New System.Windows.Forms.Button
        Me.DataGridView3 = New System.Windows.Forms.DataGridView
        Me.Criteria = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Value = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.chkJudgeUse = New System.Windows.Forms.CheckBox
        Me.grpJudgeSettings = New System.Windows.Forms.GroupBox
        Me.butColorCodeJudges = New System.Windows.Forms.Button
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpJudgeSettings.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(10, 58)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.Size = New System.Drawing.Size(699, 672)
        Me.DataGridView1.TabIndex = 0
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.AllowUserToResizeColumns = False
        Me.DataGridView2.AllowUserToResizeRows = False
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader
        Me.DataGridView2.Location = New System.Drawing.Point(715, 58)
        Me.DataGridView2.MultiSelect = False
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        Me.DataGridView2.RowHeadersVisible = False
        Me.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView2.Size = New System.Drawing.Size(538, 410)
        Me.DataGridView2.TabIndex = 2
        '
        'butLoad
        '
        Me.butLoad.Location = New System.Drawing.Point(226, 2)
        Me.butLoad.Name = "butLoad"
        Me.butLoad.Size = New System.Drawing.Size(144, 28)
        Me.butLoad.TabIndex = 3
        Me.butLoad.Text = "Load Round"
        Me.butLoad.UseVisualStyleBackColor = True
        '
        'cboRound
        '
        Me.cboRound.FormattingEnabled = True
        Me.cboRound.Location = New System.Drawing.Point(14, 16)
        Me.cboRound.Name = "cboRound"
        Me.cboRound.Size = New System.Drawing.Size(206, 28)
        Me.cboRound.TabIndex = 4
        '
        'butDelete
        '
        Me.butDelete.Location = New System.Drawing.Point(620, 5)
        Me.butDelete.Name = "butDelete"
        Me.butDelete.Size = New System.Drawing.Size(89, 47)
        Me.butDelete.TabIndex = 5
        Me.butDelete.Text = "Delete Cell"
        Me.butDelete.UseVisualStyleBackColor = True
        '
        'butAdd
        '
        Me.butAdd.Location = New System.Drawing.Point(1177, 24)
        Me.butAdd.Name = "butAdd"
        Me.butAdd.Size = New System.Drawing.Size(75, 28)
        Me.butAdd.TabIndex = 6
        Me.butAdd.Text = "Add"
        Me.butAdd.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(715, 480)
        Me.Label1.MaximumSize = New System.Drawing.Size(200, 200)
        Me.Label1.MinimumSize = New System.Drawing.Size(200, 200)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(200, 200)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Messages appear here. "
        '
        'butDeleteRow
        '
        Me.butDeleteRow.Font = New System.Drawing.Font("Franklin Gothic Medium", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butDeleteRow.Location = New System.Drawing.Point(519, 5)
        Me.butDeleteRow.Name = "butDeleteRow"
        Me.butDeleteRow.Size = New System.Drawing.Size(95, 47)
        Me.butDeleteRow.TabIndex = 8
        Me.butDeleteRow.Text = "Delete Entire Row"
        Me.butDeleteRow.UseVisualStyleBackColor = True
        '
        'butAddPanel
        '
        Me.butAddPanel.Font = New System.Drawing.Font("Franklin Gothic Medium", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butAddPanel.Location = New System.Drawing.Point(418, 5)
        Me.butAddPanel.Name = "butAddPanel"
        Me.butAddPanel.Size = New System.Drawing.Size(95, 47)
        Me.butAddPanel.TabIndex = 9
        Me.butAddPanel.Text = "Add a new Row"
        Me.butAddPanel.UseVisualStyleBackColor = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.AllowUserToResizeColumns = False
        Me.DataGridView3.AllowUserToResizeRows = False
        Me.DataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Criteria, Me.Value})
        Me.DataGridView3.Location = New System.Drawing.Point(6, 23)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowHeadersVisible = False
        Me.DataGridView3.Size = New System.Drawing.Size(228, 92)
        Me.DataGridView3.TabIndex = 10
        '
        'Criteria
        '
        Me.Criteria.DataPropertyName = "Criteria"
        Me.Criteria.HeaderText = "Criteria"
        Me.Criteria.Name = "Criteria"
        Me.Criteria.ReadOnly = True
        '
        'Value
        '
        Me.Value.DataPropertyName = "Value"
        Me.Value.HeaderText = "Value"
        Me.Value.Name = "Value"
        '
        'chkJudgeUse
        '
        Me.chkJudgeUse.Location = New System.Drawing.Point(226, 32)
        Me.chkJudgeUse.Name = "chkJudgeUse"
        Me.chkJudgeUse.Size = New System.Drawing.Size(185, 22)
        Me.chkJudgeUse.TabIndex = 11
        Me.chkJudgeUse.Text = "Show Judge Use"
        Me.chkJudgeUse.UseVisualStyleBackColor = True
        '
        'grpJudgeSettings
        '
        Me.grpJudgeSettings.Controls.Add(Me.butColorCodeJudges)
        Me.grpJudgeSettings.Controls.Add(Me.DataGridView3)
        Me.grpJudgeSettings.Location = New System.Drawing.Point(1013, 480)
        Me.grpJudgeSettings.Name = "grpJudgeSettings"
        Me.grpJudgeSettings.Size = New System.Drawing.Size(240, 200)
        Me.grpJudgeSettings.TabIndex = 12
        Me.grpJudgeSettings.TabStop = False
        Me.grpJudgeSettings.Text = "Judge Placement Settings"
        Me.grpJudgeSettings.Visible = False
        '
        'butColorCodeJudges
        '
        Me.butColorCodeJudges.Location = New System.Drawing.Point(7, 122)
        Me.butColorCodeJudges.Name = "butColorCodeJudges"
        Me.butColorCodeJudges.Size = New System.Drawing.Size(227, 37)
        Me.butColorCodeJudges.TabIndex = 11
        Me.butColorCodeJudges.Text = "Color Code Judge Assignments"
        Me.butColorCodeJudges.UseVisualStyleBackColor = True
        '
        'frmShowPairings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 742)
        Me.Controls.Add(Me.grpJudgeSettings)
        Me.Controls.Add(Me.chkJudgeUse)
        Me.Controls.Add(Me.butAddPanel)
        Me.Controls.Add(Me.butDeleteRow)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.butAdd)
        Me.Controls.Add(Me.butDelete)
        Me.Controls.Add(Me.cboRound)
        Me.Controls.Add(Me.butLoad)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmShowPairings"
        Me.Text = "Display Pairings"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpJudgeSettings.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents butLoad As System.Windows.Forms.Button
    Friend WithEvents cboRound As System.Windows.Forms.ComboBox
    Friend WithEvents butDelete As System.Windows.Forms.Button
    Friend WithEvents butAdd As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents butDeleteRow As System.Windows.Forms.Button
    Friend WithEvents butAddPanel As System.Windows.Forms.Button
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents Criteria As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Value As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents chkJudgeUse As System.Windows.Forms.CheckBox
    Friend WithEvents grpJudgeSettings As System.Windows.Forms.GroupBox
    Friend WithEvents butColorCodeJudges As System.Windows.Forms.Button
End Class
