﻿Module modInitialize
    'All of the table structures are set in the .xsd file, so you only need to populate the settings
    Sub InitializeTourneySettings(ByRef DS)
        'tourney settings table
        If DS.Tables.IndexOf("TOURN_SETTING") = -1 Then
            DS.Tables.Add("TOURN_SETTING")
        End If
        FieldCheck(DS, "TOURN_SETTING", "ID", "System.Int16")
        FieldCheck(DS, "TOURN_SETTING", "TAG", "System.String")
        FieldCheck(DS, "TOURN_SETTING", "VALUE", "System.String")
        TagCheck(DS, "TOURN_SETTING", "DownloadSite", "iDebate.org")
        TagCheck(DS, "TOURN_SETTING", "Online", "Track Users")
        TagCheck(DS, "TOURN_SETTING", "TourneyType", "Multi-Event")
        TagCheck(DS, "TOURN_SETTING", "SuppressNavMessages", "False")
        TagCheck(DS, "TOURN_SETTING", "UseActualTime", "False")
        TagCheck(DS, "TOURN_SETTING", "CrossEventEntry", "True")
    End Sub
    Sub TagCheck(ByRef ds As DataSet, ByVal strTblName As String, ByVal strTag As String, ByVal strValue As String)
        'checks for a particular tag in a table; exits if it's there, adds it if it's not
        'check if it exists
        Dim foundrow As DataRow()
        foundrow = ds.Tables(strTblName).Select("TAG='" & strTag & "'")
        'does, so exit
        If foundrow.Length = 1 Then Exit Sub
        'duplicate, so delete duplicate instances
        Dim x As Integer
        If foundrow.Length > 1 Then
            For x = 1 To foundrow.Length - 1
                foundrow(x).Delete()
            Next x
            ds.Tables(strTblName).AcceptChanges()
            Exit Sub
        End If
        'add if it doesn't
        Dim dr As DataRow
        dr = ds.Tables(strTblName).NewRow
        dr.Item("TAG") = strTag : dr.Item("VALUE") = strValue
        ds.Tables(strTblName).Rows.Add(dr)
        ds.Tables(strTblName).AcceptChanges()
    End Sub
    Sub FieldCheck(ByRef ds As DataSet, ByVal tablename As String, ByVal fieldname As String, ByVal strType As String)
        'checks if a field exists in a table, if not add it
        If ds.Tables(tablename).Columns.Contains(fieldname) = True Then Exit Sub
        ds.Tables(tablename).Columns.Add(fieldname, System.Type.GetType(strType))
        If tablename.ToUpper = "JUDGE" And InStr(fieldname.ToUpper, "EVENT") > 0 Then Call MarkAsTrue(ds, tablename, fieldname)
        If tablename.ToUpper = "JUDGE" And InStr(fieldname.ToUpper, "TIME") > 0 Then Call MarkAsTrue(ds, tablename, fieldname)
        If tablename.ToUpper = "ROOM" And InStr(fieldname.ToUpper, "EVENT") > 0 Then Call MarkAsTrue(ds, tablename, fieldname)
        If tablename.ToUpper = "ROOM" And InStr(fieldname.ToUpper, "TIME") > 0 Then Call MarkAsTrue(ds, tablename, fieldname)
    End Sub
    Sub MarkAsTrue(ByRef ds As DataSet, ByVal tablename As String, ByVal fieldname As String)
        For x = 0 To ds.Tables(tablename).Rows.Count - 1
            ds.Tables(tablename).Rows(x).Item(fieldname) = True
        Next x
        ds.Tables(tablename).Columns(fieldname).DefaultValue = True
    End Sub
    Sub InitializeDivisions(ByRef ds)
        Dim x, ctr As Integer
        Dim dr As DataRow
        For x = 0 To ds.Tables("EVENT").Rows.Count - 1
            'Debaters
            dr = ds.Tables("EVENT_SETTING").NewRow()
            ctr += 1 : dr.Item("ID") = ctr : dr.Item("Event") = ds.Tables("EVENT").Rows(x).Item("ID")
            dr.Item("TAG") = "DebatersPerTeam" : dr.Item("Value") = 2 : ds.Tables("EVENT_SETTING").Rows.Add(dr)
            'Level
            dr = ds.Tables("EVENT_SETTING").NewRow()
            ctr += 1 : dr.Item("ID") = ctr : dr.Item("Event") = ds.Tables("EVENT").Rows(x).Item("ID")
            dr.Item("TAG") = "Level" : dr.Item("Value") = "Open" : ds.Tables("EVENT_SETTING").Rows.Add(dr)
            'nPrelims
            dr = ds.Tables("EVENT_SETTING").NewRow()
            ctr += 1 : dr.Item("ID") = ctr : dr.Item("Event") = ds.Tables("EVENT").Rows(x).Item("ID")
            dr.Item("TAG") = "nPrelims" : dr.Item("Value") = 8 : ds.Tables("EVENT_SETTING").Rows.Add(dr)
            'nElims
            dr = ds.Tables("EVENT_SETTING").NewRow()
            ctr += 1 : dr.Item("ID") = ctr : dr.Item("Event") = ds.Tables("EVENT").Rows(x).Item("ID")
            dr.Item("TAG") = "nElims" : dr.Item("Value") = 5 : ds.Tables("EVENT_SETTING").Rows.Add(dr)
            'SideDesignations
            dr = ds.Tables("EVENT_SETTING").NewRow()
            ctr += 1 : dr.Item("ID") = ctr : dr.Item("Event") = ds.Tables("EVENT").Rows(x).Item("ID")
            dr.Item("TAG") = "SideDesignations" : dr.Item("Value") = "AffNeg" : ds.Tables("EVENT_SETTING").Rows.Add(dr)
            'TeamsPerRound
            dr = ds.Tables("EVENT_SETTING").NewRow()
            ctr += 1 : dr.Item("ID") = ctr : dr.Item("Event") = ds.Tables("EVENT").Rows(x).Item("ID")
            dr.Item("TAG") = "TeamsPerRound" : dr.Item("Value") = 2 : ds.Tables("EVENT_SETTING").Rows.Add(dr)
        Next
        ds.Tables("EVENT_SETTING").AcceptChanges()
    End Sub
    Sub InitializeTieBreakers(ByRef ds As DataSet)

        'If ds.Tables.IndexOf("TIEBREAK_SET") <> -1 Then Exit Sub

        Dim dr As DataRow
        Dim x As Integer
        For x = ds.Tables("TIEBREAK_SET").Rows.Count - 1 To 0 Step -1
            ds.Tables("TIEBREAK_SET").Rows(x).Delete()
        Next

        'SET UP DEFAULT TB_SET
        ds.Tables("TIEBREAK_SET").AcceptChanges()
        dr = ds.Tables("TIEBREAK_SET").NewRow
        dr.Item("ID") = 1 : dr.Item("TBSET_NAME") = "Prelim - Teams" : dr.Item("ScoreFor") = "Team" : ds.Tables("TIEBREAK_SET").Rows.Add(dr)
        dr = ds.Tables("TIEBREAK_SET").NewRow
        dr.Item("ID") = 2 : dr.Item("TBSET_NAME") = "Elim - Teams" : dr.Item("ScoreFor") = "Team" : ds.Tables("TIEBREAK_SET").Rows.Add(dr)
        dr = ds.Tables("TIEBREAK_SET").NewRow
        dr.Item("ID") = 3 : dr.Item("TBSET_NAME") = "Prelim - Speakers" : dr.Item("ScoreFor") = "Speaker" : ds.Tables("TIEBREAK_SET").Rows.Add(dr)
        dr = ds.Tables("TIEBREAK_SET").NewRow
        'SET UP DEFAULT TIEBREAKERS FOR THE TB_SET
        ds.Tables("TIEBREAK").Clear()
        'team tiebreakers - row 1/wins
        dr = ds.Tables("TIEBREAK").NewRow : x = x + 1 : dr.Item("ID") = x
        dr.Item("SortOrder") = 1 : dr.Item("ScoreID") = 1 : dr.Item("HowToCalculate") = "Sum" : dr.Item("Tag") = "None"
        dr.Item("Drops") = 0 : dr.Item("ForOpponent") = False : dr.Item("TB_SET") = 1
        dr.Item("Label") = "Wins"
        ds.Tables("TIEBREAK").Rows.Add(dr)
        'team tiebreakers - total points
        dr = ds.Tables("TIEBREAK").NewRow : x = x + 1 : dr.Item("ID") = x
        dr.Item("SortOrder") = 2 : dr.Item("ScoreID") = 2 : dr.Item("HowToCalculate") = "Sum" : dr.Item("Tag") = "None"
        dr.Item("Drops") = 0 : dr.Item("ForOpponent") = False : dr.Item("TB_SET") = 1
        dr.Item("Label") = "Total team speaker points"
        ds.Tables("TIEBREAK").Rows.Add(dr)
        'team tiebreakers - hi-lo
        dr = ds.Tables("TIEBREAK").NewRow : x = x + 1 : dr.Item("ID") = x
        dr.Item("SortOrder") = 3 : dr.Item("ScoreID") = 2 : dr.Item("HowToCalculate") = "HighLowDrop" : dr.Item("Tag") = "None"
        dr.Item("Drops") = 1 : dr.Item("ForOpponent") = False : dr.Item("TB_SET") = 1
        dr.Item("Label") = "Hi-Lo team speaker points"
        ds.Tables("TIEBREAK").Rows.Add(dr)
        'team tiebreakers - Opp Wins
        dr = ds.Tables("TIEBREAK").NewRow : x = x + 1 : dr.Item("ID") = x
        dr.Item("SortOrder") = 4 : dr.Item("ScoreID") = 1 : dr.Item("HowToCalculate") = "Sum" : dr.Item("Tag") = "OppWins"
        dr.Item("Drops") = 0 : dr.Item("ForOpponent") = True : dr.Item("TB_SET") = 1
        dr.Item("Label") = "Opposition Wins"
        ds.Tables("TIEBREAK").Rows.Add(dr)

        'Speaker tiebreakers - row 1/HL pts
        dr = ds.Tables("TIEBREAK").NewRow : x = x + 1 : dr.Item("ID") = x
        dr.Item("SortOrder") = 1 : dr.Item("ScoreID") = 2 : dr.Item("HowToCalculate") = "HighLowDrop" : dr.Item("Tag") = "None"
        dr.Item("Drops") = 1 : dr.Item("ForOpponent") = False : dr.Item("TB_SET") = 3
        dr.Item("Label") = "Hi-Lo Speaker points"
        ds.Tables("TIEBREAK").Rows.Add(dr)

        'Speaker tiebreakers - row 2/Total
        dr = ds.Tables("TIEBREAK").NewRow : x = x + 1 : dr.Item("ID") = x
        dr.Item("SortOrder") = 2 : dr.Item("ScoreID") = 2 : dr.Item("HowToCalculate") = "HighLowDrop" : dr.Item("Tag") = "None"
        dr.Item("Drops") = 2 : dr.Item("ForOpponent") = False : dr.Item("TB_SET") = 3
        dr.Item("Label") = "2x Hi-Lo Speaker points"
        ds.Tables("TIEBREAK").Rows.Add(dr)

        'Speaker tiebreakers - row 2/Total
        dr = ds.Tables("TIEBREAK").NewRow : x = x + 1 : dr.Item("ID") = x
        dr.Item("SortOrder") = 3 : dr.Item("ScoreID") = 2 : dr.Item("HowToCalculate") = "Special" : dr.Item("Tag") = "JudgeVariance"
        dr.Item("Drops") = 0 : dr.Item("ForOpponent") = False : dr.Item("TB_SET") = 3
        dr.Item("Label") = "Judge Variance"
        ds.Tables("TIEBREAK").Rows.Add(dr)

        'save
        ds.AcceptChanges()

    End Sub
    Sub InitializeScores(ByRef ds As DataSet)

        'don't reset because ID index needs to stay constant

        'If ds.Tables.IndexOf("SCORES") <> -1 Then Exit Sub

        'clear the table
        Dim dr As DataRow
        Dim x As Integer
        For x = ds.Tables("SCORES").Rows.Count - 1 To 0 Step -1
            ds.Tables("SCORES").Rows(x).Delete()
        Next
        ds.Tables("SCORES").AcceptChanges()
        ds.Tables("Scores").Clear()
        ds.Tables("Scores").Columns("ID").AutoIncrementSeed = 1

        dr = ds.Tables("SCORES").NewRow
        dr.Item("SCOREFOR") = "Team" : dr.Item("SCORE_NAME") = "Ballot" : dr.Item("SORTORDER") = "DESC"
        ds.Tables("SCORES").Rows.Add(dr)

        dr = ds.Tables("SCORES").NewRow
        dr.Item("SCOREFOR") = "Speaker" : dr.Item("SCORE_NAME") = "Speaker Points" : dr.Item("SORTORDER") = "DESC"
        ds.Tables("SCORES").Rows.Add(dr)

        dr = ds.Tables("SCORES").NewRow
        dr.Item("SCOREFOR") = "Speaker" : dr.Item("SCORE_NAME") = "Speaker Rank" : dr.Item("SORTORDER") = "ASC"
        ds.Tables("SCORES").Rows.Add(dr)

        dr = ds.Tables("SCORES").NewRow
        dr.Item("SCOREFOR") = "Team" : dr.Item("SCORE_NAME") = "Team Points" : dr.Item("SORTORDER") = "DESC"
        ds.Tables("SCORES").Rows.Add(dr)

        dr = ds.Tables("SCORES").NewRow
        dr.Item("SCOREFOR") = "Team" : dr.Item("SCORE_NAME") = "Team Rank" : dr.Item("SORTORDER") = "ASC"
        ds.Tables("SCORES").Rows.Add(dr)

        ds.AcceptChanges()

    End Sub
    Sub InitializeScoreSettings(ByRef ds As DataSet)

        'If ds.Tables.IndexOf("SCORE_SETTING") <> -1 Then Exit Sub

        Dim dr As DataRow

        For x = ds.Tables("SCORE_SETTING").Rows.Count - 1 To 0 Step -1
            ds.Tables("SCORE_SETTING").Rows(x).Delete()
        Next

        For x = 0 To ds.Tables("Tiebreak_Set").Rows.Count - 1
            For y = 1 To 5
                dr = ds.Tables("SCORE_SETTING").NewRow
                dr.Item("TB_SET") = ds.Tables("Tiebreak_set").Rows(x).Item("ID")
                dr.Item("Score") = y
                If y = 1 Then dr.Item("MAX") = 1 : dr.Item("MIN") = 0
                If y = 2 Or y = 4 Then dr.Item("MAX") = 30 : dr.Item("MIN") = 1
                If y = 3 Or y = 5 Then dr.Item("MAX") = 4 : dr.Item("MIN") = 1
                dr.Item("DUPESOK") = "False" : If y = 2 Or y = 4 Then dr.Item("DUPESOK") = "False"
                dr.Item("DecimalIncrements") = 0 : If y = 2 Or y = 4 Then If y = 2 Or y = 4 Then dr.Item("DECIMALINCREMENTS") = 0.1
                ds.Tables("SCORE_SETTING").Rows.Add(dr)
            Next y
        Next x

    End Sub
    Sub InitializeTimeSlots(ByRef ds, ByVal nRounds)

        Dim q As Integer = MsgBox("This will erase and reset all timeslots.  If you have already set up the rounds, it will be much better to add or delete individual timeslots as necessary.  If you reset all the timeslots, make sure you visit the SET UP ROUND SCHEDULE screen and reset all the timeslots.  Continue with reset?", MsgBoxStyle.YesNo)
        If q = vbNo Then Exit Sub

        'check that the table exists and is formatted correctly
        If ds.Tables.IndexOf("TIMESLOT") = -1 Then
            ds.Tables.Add("TIMESLOT")
        End If
        FieldCheck(ds, "TIMESLOT", "ID", "System.Int64")
        FieldCheck(ds, "TIMESLOT", "NAME", "System.String")
        FieldCheck(ds, "TIMESLOT", "STARTTIME", "System.DateTime")
        FieldCheck(ds, "TIMESLOT", "ENDTIME", "System.DateTime")


        ds.tables("Timeslot").clear()
        Dim dr As DataRow
        For x = 0 To nRounds - 1
            dr = ds.tables("TimeSlot").newrow
            dr.Item("Name") = "TimeSlot # " & x + 1
            If dr.Item("ID") Is System.DBNull.Value Then
                dr.Item("ID") = x + 1
            End If
            ds.tables("TimeSlot").rows.add(dr)
        Next x

    End Sub
    Sub InitializeViewSettings(ByRef ds As DataSet)
        If ds.Tables.IndexOf("VIEWSETTINGS") = -1 Then
            ds.Tables.Add("VIEWSETTINGS")
        End If
        FieldCheck(ds, "VIEWSETTINGS", "ROUND", "System.Int16")
        FieldCheck(ds, "VIEWSETTINGS", "TAG", "System.String")
        FieldCheck(ds, "VIEWSETTINGS", "SORTORDER", "System.Int16")

    End Sub
    Sub InitializeJudges(ByRef ds As DataSet)
        If ds.Tables.IndexOf("JUDGE") = -1 Then
            ds.Tables.Add("JUDGE")
        End If
        'add columns for every event
        For x = 0 To ds.Tables("Event").Rows.Count - 1
            FieldCheck(ds, "JUDGE", "Event" & ds.Tables("Event").Rows(x).Item("ID"), "System.Boolean")
        Next x
        'add columns for every timeslot
        For x = 0 To ds.Tables("Timeslot").Rows.Count - 1
            FieldCheck(ds, "JUDGE", "Timeslot" & ds.Tables("timeslot").Rows(x).Item("ID"), "System.Boolean")
        Next x

    End Sub
    Sub InitializeRooms(ByRef ds As DataSet)
        If ds.Tables.IndexOf("ROOM") = -1 Then
            ds.Tables.Add("ROOM")
        End If
        'add columns for every event
        For x = 0 To ds.Tables("Event").Rows.Count - 1
            FieldCheck(ds, "ROOM", "Event" & ds.Tables("Event").Rows(x).Item("ID"), "System.Boolean")
        Next x
        'add columns for every timeslot
        For x = 0 To ds.Tables("Timeslot").Rows.Count - 1
            FieldCheck(ds, "ROOM", "Timeslot" & ds.Tables("timeslot").Rows(x).Item("ID"), "System.Boolean")
        Next x
    End Sub
    Function SetupCompletionStatus(ByVal ds As DataSet) As String
        SetupCompletionStatus = "Setup complete!  Ready to start pairing."

        'TOURNAMENT-WIDE STUFF
        If ds.Tables("Tourn").Rows(0).Item("Tournname").trim = "" Then
            SetupCompletionStatus = "No tournament name is identified.  Enter one by clicking the ENTER TOURNAMENT-WIDE SETTINGS button." : Exit Function
        End If
        If ds.Tables("Tourn").Rows(0).Item("ID") = 0 Then
            SetupCompletionStatus = "No tournament has been identified.  Either download one or start from scratch." : Exit Function
        End If
        If ds.Tables.IndexOf("TOURN_SETTING") = -1 Then
            SetupCompletionStatus = "No tournament settings exist in the database.  Click on the ENTER TOURNAMENT-WIDE SETTINGS button to create defaults." : Exit Function
        End If
        If ds.Tables("TOURN_SETTING").Rows.Count < 6 Then
            SetupCompletionStatus = "Not all tournament settings exist in the database.  Click on the ENTER TOURNAMENT-WIDE SETTINGS button to create defaults." : Exit Function
        End If

        'DIVISION-WIDE STUFF
        'division exist
        If ds.Tables("Event").Rows.Count = 0 Then
            SetupCompletionStatus = "No divisions have been entered yet.  Click on the SET UP DIVISIONS button to enter them." : Exit Function
        End If
        'all divisions have settings
        Dim fdRows As DataRow()
        For x = 0 To ds.Tables("Event").Rows.Count - 1
            fdRows = ds.Tables("Event_Setting").Select("Event=" & ds.Tables("Event").Rows(x).Item("ID"))
            If fdRows.Length = 0 Then SetupCompletionStatus = "One or more divisions appear to be missing their settings.  Click on the SET UP DIVISIONS button to enter them.  You can view the event settings by clicking on the name of each event on the set up screen." : Exit Function
            If fdRows.Length < 9 Then SetupCompletionStatus = "One or more divisions appear to have incomplete settings.  Click on the SET UP DIVISIONS button to reset them.  You can view the event settings by clicking on the name of each event on the set up screen; all divisions should have 9 settings." : Exit Function
        Next x

        'TIEBREAKERS
        'at least 1 TIBREAK_SET
        If ds.Tables("Tiebreak_Set").Rows.Count = 0 Then
            SetupCompletionStatus = "There are no tiebreaker sets set up.  Click on the SET UP TIEBREAKERS button to enter them.  Click the help button on that page to familiarize yourself with the difference between tiebreakers, tiebreaker sets, and scores." : Exit Function
        End If
        'all tiebreaker sets have tiebreakers
        For x = 0 To ds.Tables("Tiebreak_Set").Rows.Count - 1
            fdRows = ds.Tables("Tiebreak").Select("TB_Set=" & ds.Tables("Tiebreak_set").Rows(x).Item("ID"))
            If fdRows.Length = 0 Then SetupCompletionStatus = "At least one tiebreaker set has no tiebreakers.  Click on the SET UP TIEBREAKERS button to enter them.  Click the help button on that page to familiarize yourself with the difference between tiebreakers, tiebreaker sets, and scores." : Exit Function
        Next x
        'scores exit
        If ds.Tables("Scores").Rows.Count = 0 Then
            SetupCompletionStatus = "No scores appear to be set up.  Click on the SET UP TIEBREAKERS button to enter them.  Click the help button on that page to familiarize yourself with the difference between tiebreakers, tiebreaker sets, and scores." : Exit Function
        End If
        'scores have settings
        If ds.Tables("Score_Setting").Rows.Count <> (5 * ds.Tables("Tiebreak_Set").Rows.Count) Then SetupCompletionStatus = "Each score is not matched to a group of settings.  Click on the SET UP TIEBREAKERS button to enter them.  Click the help button on that page to familiarize yourself with the difference between tiebreakers, tiebreaker sets, and scores." : Exit Function
        For x = 0 To ds.Tables("Scores").Rows.Count - 1
            fdRows = ds.Tables("Score_Setting").Select("Score=" & ds.Tables("Scores").Rows(x).Item("ID"))
            If fdRows.Length = 0 Then SetupCompletionStatus = "At least one of the scores has no settings.  Click on the SET UP TIEBREAKERS button to enter them.  Click the help button on that page to familiarize yourself with the difference between tiebreakers, tiebreaker sets, and scores." : Exit Function
        Next x

        'ROUNDS are ready to go

        'REFERENTIAL INTEGRITY CHECKS -- won't these fire on load?
        'Schools and students for ENTRY
        'schools for ENTRY_STUDENT
        'events for EVENT_SETTING
        'Judge, panel, and entry for BALLOT
        'ballot and recipient for BALLOT_SCRE
        'score for SCORE_SETTING
        'Event for TIEBREAK
        'School for JUDGE
        'Event, timeslot, TB_SET for ROUND
        'Round for PANEL
        'Event, round, entry, for ELIMSEED

    End Function
    Sub CalcPrefAverages(ByRef ds)
        Dim str As String = ""
        str &= "start: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        For x = 0 To ds.tables("Judge").rows.count - 1
            ds.tables("Judge").rows(x).item("AvgPref") = FormatNumber(ds.Tables("JudgePref").Compute("Avg(OrdPct)", "Judge = " & ds.tables("Judge").rows(x).item("ID") & "and rating<999 and rating>0"), 1)
        Next x
        str &= "end: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        'MsgBox(str)
    End Sub
    Function GetAvgPref(ByVal ds As DataSet, ByVal Judge As Integer) As Single
        Dim fdPrefs As DataRow()
        fdPrefs = ds.Tables("JudgePref").Select("Judge=" & Judge & " and rating>0")
        GetAvgPref = ds.Tables("JudgePref").Compute("Avg(Rating)", "Judge = " & Judge)
        'GetAvgPref = fdPrefs.Average(Function(number) Convert.ToInt64(number))
    End Function
End Module
