﻿Module modTieBreaker
    
    Private DS As New DataSet
    Dim foundrow As DataRow()

    Public Function MakeTBTable(ByVal DtS As DataSet, ByVal Round As Integer, ByVal SortType As String, ByVal strTeamDisplay As String) As DataTable
        'takes the dataset, a tb_set, an event, sort type (team or speaker) and timeslot rounds are through
        'need to test to make sure that the tiebreakers requested have been collected

        DS = DtS.Copy
        Dim x, y As Integer

        'Pull eventID and timeslot by round
        Dim drRound As DataRow
        drRound = DS.Tables("Round").Rows.Find(Round)
        Dim EventID As Integer = drRound.Item("Event")
        Dim timeslot As Integer = drRound.Item("TimeSlot")
        Dim TBSET As Integer = drRound.Item("TB_SET")

        Dim DT As New DataTable : Dim dr As DataRow
        Dim strSortOrder As String = ""

        'first 3 columns are set
        DT.Columns.Add("COMPETITOR", System.Type.GetType("System.Int64"))
        DT.Columns.Add("COMPETITORNAME", System.Type.GetType("System.String"))
        DT.Columns.Add("SEED", System.Type.GetType("System.Int64"))

        'find the teams to sort
        Dim dtvEntry As New DataView(DS.Tables("ENTRY"))
        dtvEntry.RowFilter = "EVENT = " & EventID.ToString

        'if it's a preset, load ratings into seed and be done with it
        If drRound.Item("PairingScheme").toupper = "PRESET" And SortType = "TEAM" Then
            For x = 0 To dtvEntry.Count - 1
                dr = DT.NewRow
                dr.Item("Competitor") = dtvEntry(x).Item("ID")
                dr.Item("CompetitorName") = dtvEntry(x).Item(strTeamDisplay)
                dr.Item("Seed") = dtvEntry(x).Item("Rating")
                DT.Rows.Add(dr)
            Next x
            Return DT
            Exit Function
        End If

        'strip rounds later than the specified timeslot
        For x = DS.Tables("Round").Rows.Count - 1 To 0 Step -1
            If DS.Tables("Round").Rows(x).Item("Timeslot") > timeslot Then DS.Tables("Round").Rows(x).Delete()
        Next x

        'TEAM and SPEAKER are valid sort types
        SortType = SortType.ToUpper

        'retrieve TBset ID from the name
        'get the rows for that TBSET and sort
        Dim dtvTB As New DataView(DS.Tables("TIEBREAK"))
        dtvTB.RowFilter = "TB_SET = " & TBSET
        dtvTB.Sort = "SortOrder ASC"

        'create columns in order of tiebreaker set
        Dim drScore As DataRow : Dim strDummy As String
        For x = 0 To dtvTB.Count - 1
            If dtvTB(x).Item("TAG") <> "None" Then
                DT.Columns.Add(dtvTB(x).Item("TAG"), System.Type.GetType("System.Single"))
                strDummy = dtvTB(x).Item("TAG")
            Else
                DT.Columns.Add(dtvTB(x).Item("LABEL"), System.Type.GetType("System.Single"))
                strDummy = dtvTB(x).Item("LABEL")
            End If
            If strSortOrder <> "" Then strSortOrder &= ", "
            drScore = DS.Tables("Scores").Rows.Find(dtvTB(x).Item("SCOREID"))
            strSortOrder &= strDummy & " " & drScore.Item("SortOrder")
        Next

        'Fill with raw values, and build sortstring
        For x = 0 To dtvEntry.Count - 1
            dr = DT.NewRow
            dr.Item("Competitor") = dtvEntry(x).Item("ID")
            If SortType = "TEAM" Then
                dr.Item("CompetitorName") = FullNameMaker(DS, dr.Item("Competitor"), strTeamDisplay, 1)
            Else
                dr.Item("CompetitorName") = GetName(DS.Tables("ENTRY_STUDENT"), dr.Item("Competitor"), "Last")
            End If
            dr.Item("Seed") = 0
            dr.Item("SchoolName") = "XXXX"
            For y = 4 To 4 + dtvTB.Count - 1
                dr.Item(y) = GetScore(SortType, dr.Item("Competitor"), dtvTB(y - 4).Item("ID"))
            Next y
            DT.Rows.Add(dr)
        Next x

        'copy the datatable to a dataview and sort it
        Dim dvTable As New DataView(DT)
        dvTable.Sort = strSortOrder
        'clone the table and clear it, then add the rows in seed order
        Dim clonetable As New DataTable
        clonetable = DT.Clone : clonetable.Clear()
        For x = 0 To dvTable.Count - 1
            dr = clonetable.NewRow
            For y = 0 To DT.Columns.Count - 1
                dr.Item(y) = dvTable(x).Item(y)
            Next y
            dr.Item("Seed") = x + 1
            clonetable.Rows.Add(dr)
        Next x

        'set table to return
        MakeTBTable = clonetable
    End Function
    Function GetScore(ByVal SortType As String, ByVal CompetitorID As Integer, ByVal TBID As Integer) As Single
        'receives the sortType as TEAM OR SPEAKER, a competitorID, and the ID value for the tiebreak row
        'first, pull the tiebreak row and use it's values to figure how to compute the tiebreaker
        Dim drTiebreak As DataRow
        drTiebreak = DS.Tables("Tiebreak").Rows.Find(TBID)
        Dim drScore As DataRow
        drScore = DS.Tables("Scores").Rows.Find(drTiebreak.Item("ScoreID"))
        If SortType = "TEAM" Then
            If drScore.Item("ScoreFor").toupper = "SPEAKER" And drTiebreak.Item("Tag") = "None" And (drTiebreak.Item("HowToCalculate") = "Sum" Or drTiebreak.Item("HowToCalculate") = "HighLowDrop") Then GetScore = SumSpkrByTeam(CompetitorID, drTiebreak.Item("ScoreID"), drTiebreak.Item("Drops"))
            If drScore.Item("ScoreFor").toupper = "TEAM" And drTiebreak.Item("Tag") = "None" And drTiebreak.Item("HowToCalculate") = "Sum" Then GetScore = SumScore(CompetitorID, drTiebreak.Item("ScoreID"), drTiebreak.Item("Drops"))
            If drScore.Item("ScoreFor").toupper = "TEAM" And drTiebreak.Item("Tag") = "Wins" Then GetScore = GetWins(CompetitorID)
            If drScore.Item("ScoreFor").toupper = "TEAM" And drTiebreak.Item("Tag") = "OppWins" Then GetScore = GetOppWins(CompetitorID)
            If drScore.Item("ScoreFor").toupper = "TEAM" And drTiebreak.Item("Tag") = "Ballots" Then GetScore = SumScore(CompetitorID, drTiebreak.Item("ScoreID"), drTiebreak.Item("Drops"))
        ElseIf SortType = "SPEAKER" Then
            If drTiebreak.Item("Tag") = "None" And drTiebreak.Item("HowToCalculate") = "Sum" Then GetScore = SumScore(CompetitorID, drTiebreak.Item("ScoreID"), drTiebreak.Item("Drops"))
        End If
    End Function
    Function SumSpkrByTeam(ByVal Entry, ByVal strField, ByVal nHiLo) As Single
        'receive teamID, raw score to calculate, pulls all speakers off the team and generates a team total
        SumSpkrByTeam = 0
        Dim fdSpkrs, fdBallots As DataRow()
        'Pull all speakers on the team
        fdSpkrs = DS.Tables("Entry_Student").Select("Entry=" & Entry)

        'Set up 1 datatable to store raw scores you can sort by judge
        Dim dt As New DataTable
        dt.Columns.Add("Panel", System.Type.GetType("System.Int64"))
        dt.Columns.Add("Judge", System.Type.GetType("System.Int64"))
        dt.Columns.Add("Score", System.Type.GetType("System.Single"))
        'Set up 2nd datatable to hold summed team scores by judge
        Dim dtScores As New DataTable
        dtScores.Columns.Add("Score", System.Type.GetType("System.Single"))

        Dim dr, drBallot As DataRow
        'pull all ballot by competitor
        For x = 0 To fdSpkrs.Length - 1
            fdBallots = DS.Tables("Ballot_Score").Select("Recipient=" & fdSpkrs(x).Item("ID") & " and Score_ID=" & strField)
            For y = 0 To fdBallots.Length - 1
                drBallot = DS.Tables("Ballot").Rows.Find(fdBallots(y).Item("Ballot"))
                dr = dt.NewRow
                dr.Item("Judge") = drBallot.Item("Judge")
                dr.Item("Panel") = drBallot.Item("Panel")
                dr.Item("Score") = fdBallots(x).Item("Score")
                dt.Rows.Add(dr)
            Next
        Next x
        dt.DefaultView.Sort = "Panel asc, judge asc"
        'now the datatable includes all ballot scores, sorted by panel and judge

        'Put the team total for each judge on a row of dtScores
        Dim tot As Single
        For x = 0 To dt.DefaultView.Count - 1
            'drv = dt.DefaultView.Item(x)
            tot += dt.DefaultView.Item(x).Item("Score")
            If x = dt.DefaultView.Count - 1 Then
                dr = dtScores.NewRow : dr.Item("Score") = tot : dtScores.Rows.Add(dr) : tot = 0
            ElseIf dt.DefaultView.Item(x).Item("Judge") <> dt.DefaultView.Item(x + 1).Item("Judge") Then
                dr = dtScores.NewRow : dr.Item("Score") = tot : dtScores.Rows.Add(dr) : tot = 0
            End If
        Next x

        'Drop highs and lows
        dtScores.DefaultView.Sort = "Score ASC"
        For x = 0 To dtScores.DefaultView.Count - 1
            If x >= nHiLo And x <= dtScores.DefaultView.Count - 1 - x Then SumSpkrByTeam += dtScores.DefaultView.Item(x).Item("Score")
        Next x
        SumSpkrByTeam = FormatNumber(SumSpkrByTeam, 2)

    End Function
    Function SumScore(ByVal CompetitorID, ByVal strField, ByVal nHiLo) As Single
        'receive competitorID, raw score to calculate, number of hi-lo drops
        'assigns one score per panel, and drops the highs and lows

        SumScore = 0

        'pull all ballot by competitor
        Dim fdBallots As DataRow()
        fdBallots = DS.Tables("Ballot_Score").Select("Recipient=" & CompetitorID & " and Score_ID=" & strField, "Score DESC")

        'drop highs and lows
        For x = 0 To fdBallots.Length - 1
            If x >= nHiLo And x <= (fdBallots.Length - 1 - nHiLo) Then
                SumScore += fdBallots(x).Item("Score")
            End If
        Next x

    End Function
    Function GetTeamPoints(ByVal team As Integer) As Single
        GetTeamPoints = 0
        Dim strSearch As String = ""
        strSearch = GetSpeakersByTeam(DS, team, "Recipient")
        'find the record that stores the points
        foundrow = DS.Tables("Ballot_Score").Select("(" & strSearch & ") and Score_ID=" & 2)
        Dim x As Integer
        For x = 0 To foundrow.Length - 1
            GetTeamPoints += foundrow(x).Item("Score")
        Next
        x = 1
        'Find the decimal value for TB 3 and make it 2 if less than .1
        GetTeamPoints = FormatNumber(GetTeamPoints, x)
    End Function
    Function GetBallot_Score(ByVal Ballot As Integer, ByVal ScoreID As Integer)
        'returns a score for a specific tiebreaker on a specific ballot from the ballot_score table
        'tiebreaker is the MasterID number, so need to find which tiebreaker ID is the master TB number
        Dim foundscore As DataRow()
        foundscore = DS.Tables("Ballot_Score").Select("Ballot=" & Ballot & " and Score_ID=" & ScoreID)
        GetBallot_Score = -99
        If foundscore.Length > 0 Then GetBallot_Score = foundscore(0).Item("Score")
    End Function
    Function GetWins(ByVal compID As Integer) As Single
        Dim x, score As Integer
        GetWins = 0
        Dim y As Integer = 1
        'pull all ballots involving team
        foundrow = ds.Tables("Ballot").Select("Entry=" & compID, "Panel ASC")
        Dim voteFor, voteVs As Integer
        'loop through the ballots in panel order
        For x = 0 To foundrow.Length - 1
            'process if bye
            If foundrow(x).Item("Side") = -1 Then
                GetWins += 1
            Else
                'pull all the win field from each ballot and count votes
                score = GetBallot_Score(foundrow(x).Item("ID"), 1)
                If score = 1 Or score = 2 Then voteFor += 1 Else voteVs += 1
                'check for last ballot on the panel; if it is, count the win and reset ballot counts
                If x = foundrow.Length - 1 Then y = 0
                If (foundrow(x).Item("Panel") <> foundrow(x + y).Item("panel")) Or y = 0 Then
                    If voteFor > voteVs Then GetWins += 1
                    voteFor = 0 : voteVs = 0
                End If
            End If
        Next x
    End Function
    Function GetOppWins(ByVal team As Integer) As Integer
        GetOppWins = 0
        'pull all ballots by team
        Dim fdBallots, fdPanel As DataRow()
        fdBallots = DS.Tables("Ballot").Select("Entry=" & team, "Panel ASC")
        'pull all the ballots for every panel the team is on
        Dim ProcessPanel As Boolean
        For x = 1 To fdBallots.Length - 1
            ProcessPanel = False
            If x = 0 Then ProcessPanel = True
            If fdBallots(x).Item("Panel") <> fdBallots(x - 1).Item("Panel") Then ProcessPanel = True
            If ProcessPanel = True Then
                fdPanel = DS.Tables("Ballot").Select("Panel=" & fdBallots(x).Item("Panel"), "Entry ASC")
                For y = 0 To fdPanel.Length - 1
                    'if the ballot isn't for the team, pull the number of wins for that team
                    If fdPanel(y).Item("Entry") <> team Then
                        If y = fdPanel.Length - 1 Then
                            GetOppWins += GetWins(fdPanel(y).Item("Entry"))
                        ElseIf fdPanel(y).Item("Entry") <> fdPanel(y + 1).Item("Entry") Then
                            GetOppWins += GetWins(fdPanel(y).Item("Entry"))
                        End If
                    End If
                Next y
            End If
        Next
    End Function
    Function GetWinsForPullUps(ByVal ds As DataSet, ByVal compID As Integer, ByVal round As Integer) As Single
        'same thing, but want to pull only the wins from the dataset and not make another entire table
        'ONLY processes rounds before the passed round
        Dim x, score As Integer
        GetWinsForPullUps = 0
        Dim y As Integer = 1
        Dim drRound, drpanel, drPanRd As DataRow
        drRound = ds.Tables("Round").Rows.Find(round)
        'pull all ballots involving team
        foundrow = ds.Tables("Ballot").Select("Entry=" & compID, "Panel ASC")
        Dim voteFor, voteVs As Integer
        'loop through the ballots in panel order
        For x = 0 To foundrow.Length - 1
            drpanel = ds.Tables("Panel").Rows.Find(foundrow(x).Item("Panel"))
            drPanRd = ds.Tables("Round").Rows.Find(drpanel.Item("Round"))
            If drPanRd.Item("timeslot") < drRound.Item("timeslot") Then
                'process if bye
                If foundrow(x).Item("Side") = -1 Then
                    GetWinsForPullUps += 1
                Else
                    'pull all the win field from each ballot and count votes
                    score = GetBallot_Score(foundrow(x).Item("ID"), 1)
                    If score = 1 Or score = 2 Then voteFor += 1 Else voteVs += 1
                    'check for last ballot on the panel; if it is, count the win and reset ballot counts
                    If x = foundrow.Length - 1 Then y = 0
                    If (foundrow(x).Item("Panel") <> foundrow(x + y).Item("panel")) Or y = 0 Then
                        If voteFor > voteVs Then GetWinsForPullUps += 1
                        voteFor = 0 : voteVs = 0
                    End If
                End If
            End If
        Next x
    End Function
    Function HadBye(ByVal ds As DataSet, ByVal round As Integer, ByVal Team As Integer) As Integer
        HadBye = 0
        Dim fdBallot As DataRow()
        Dim drPanel, drPanelRd, drRound As DataRow
        drRound = DS.Tables("Round").Rows.Find(round)

        'Pull all ballots for team
        fdBallot = ds.Tables("Ballot").Select("Entry=" & Team)
        For x = 0 To fdBallot.Length - 1
            drPanel = ds.Tables("Panel").Rows.Find(fdBallot(x).Item("Panel"))
            drPanelRd = ds.Tables("Round").Rows.Find(drPanel.Item("Round"))
            If drPanelRd.Item("Timeslot") < drRound.Item("TimeSlot") Then
                If fdBallot(x).Item("Judge") = -1 Or fdBallot(x).Item("Side") = -1 Then HadBye += 1
            End If
        Next x

    End Function
End Module
