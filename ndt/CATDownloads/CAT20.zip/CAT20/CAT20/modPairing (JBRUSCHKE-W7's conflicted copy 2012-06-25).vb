﻿Module modPairing
    Function PullBallotsByRound(ByVal ds2 As DataSet, ByVal strField As String, ByVal FieldId As Integer, ByVal round As Integer) As DataTable
        'returns a table that holds all ballots for a given judge or team in a given round
        'DT will only include a list of ballotIDS 
        Dim DT As New DataTable
        Dim dr As DataRow
        DT.Columns.Add("ID", System.Type.GetType("System.Int64"))
        'pull all ballots by judge or team for a given round; strfield can = "Judge" or "Team"
        Dim fdBallots As DataRow()
        fdBallots = ds2.Tables("Ballot").Select(strField & "=" & FieldId)
        Dim drPanel As DataRow
        For x = 0 To fdBallots.Length - 1
            drPanel = ds2.Tables("Panel").Rows.Find(fdBallots(x).Item("Panel"))
            If drPanel.Item("Round") = round Then
                dr = DT.NewRow
                dr.Item("ID") = fdBallots(x).Item("ID")
                DT.Rows.Add(dr)
            End If
        Next x
        Return DT
    End Function
    Function AddRoomToPanel(ByRef ds As DataSet, ByVal panel As Integer, ByVal Room As Integer) As String
        AddRoomToPanel = "OK"
        Dim fdPanel As DataRow
        fdPanel = ds.Tables("Panel").Rows.Find(panel)
        If fdPanel Is Nothing Then AddRoomToPanel = "Invalid panel selected.  Please select an appropriate panel and try again." : Exit Function
        fdPanel.Item("Room") = Room
    End Function
    Function AddJudgeToPanel(ByRef DS As DataSet, ByVal panel As Integer, ByVal judge As Integer) As String
        AddJudgeToPanel = "OK"
        'pull all judge ballots by panel where the judge field is blank; order by teams in ascending order
        Dim fdBallots As DataRow()
        fdBallots = DS.Tables("Ballot").Select("Panel=" & panel & " and judge=-99", "Entry DESC")
        If fdBallots.Length = 0 Then AddJudgeToPanel = "No blank place to insert the judge.  Please delete a team from this pairing first and try again." : Exit Function
        If fdBallots(0).Item("Entry") = -99 Then AddJudgeToPanel = "Please place at least one team before adding judges." : Exit Function
        'Add a judge for each unique team entry
        For x = 0 To fdBallots.Length - 1
            If x = 0 Then
                fdBallots(x).Item("Judge") = judge
            ElseIf fdBallots(x).Item("Entry") <> fdBallots(x - 1).Item("Entry") Then
                fdBallots(x).Item("Judge") = judge
            End If
        Next x
    End Function
    Function AddTeamToPanel(ByRef DS As DataSet, ByVal panel As Integer, ByVal team As Integer, ByVal Side As Integer) As String
        AddTeamToPanel = "OK"
        'pull all judge ballots by panel where the team field is blank; order by judges in ascending order
        Dim fdBallots As DataRow()
        fdBallots = DS.Tables("Ballot").Select("Panel=" & panel & " and entry=-99", "Judge ASC")
        If fdBallots.Length = 0 Then AddTeamToPanel = "No blank place to insert the team.  Please delete an existing team from the pairing and try again." : Exit Function
        'get the number of judges that need to hear the team
        Dim drPanel, drRound As DataRow
        drPanel = DS.Tables("Panel").Rows.Find(panel)
        drRound = DS.Tables("Round").Rows.Find(drPanel.Item("Round"))
        Dim nJudges = drRound.Item("JudgesPerPanel")
        If fdBallots.Length < nJudges Then
            AddTeamToPanel = "Not enough blank spots to place the team.  Try again." : Exit Function
        End If
        Dim ctr, x As Integer
        'Add a team for each unique judge entry
        For x = 0 To fdBallots.Length - 1
            If fdBallots(x).Item("Side") = Side Then fdBallots(x).Item("entry") = team : ctr += 1
        Next x
        'If you're not on enough ballots, then add in blank judge spots
        x = -1
        Do Until ctr = nJudges
            x = x + 1
            If fdBallots(x).Item("Judge") = -99 And fdBallots(x).Item("Entry") = -99 And fdBallots(x).Item("side") = Side Then
                fdBallots(x).Item("Entry") = team : ctr += 1
            End If
        Loop
    End Function
    Function AddPanel(ByRef ds As DataSet, ByVal round As Int64) As Integer
        'create a blank panel; enters -99 for teams and judges.  Returns the panelID number
        'add the panel
        Dim dr As DataRow
        dr = ds.Tables("PANEL").NewRow
        dr.Item("Round") = round
        ds.Tables("Panel").Rows.Add(dr)
        ds.Tables("Panel").AcceptChanges()
        Dim PanelID = dr.Item("ID")
        'pull the number of teams per debate; 
        Dim drRound As DataRow
        drRound = ds.Tables("Round").Rows.Find(round)
        Dim TeamsPerDebate As Integer = getEventSetting(ds, drRound.Item("Event"), "TeamsPerRound")
        'add a ballot for each team on panel by each judge
        Dim x, y As Integer
        For y = 0 To drRound.Item("JudgesPerPanel") - 1
            For x = 0 To TeamsPerDebate - 1
                dr = ds.Tables("Ballot").NewRow
                dr.Item("Panel") = PanelID
                dr.Item("Judge") = -99
                dr.Item("Entry") = -99
                dr.Item("Side") = x + 1
                ds.Tables("Ballot").Rows.Add(dr)
            Next x
        Next y
        Return PanelID
    End Function
    Function ActiveInTimeSlot(ByVal ds As DataSet, ByVal ID As Integer, ByVal round As Integer, ByVal strField As String) As Boolean
        'tells whether a team or judge is in used during current timeblock
        ActiveInTimeSlot = False
        'pull all ballots by judge or team for a given round; strfield can = "Judge" or "Entry"
        Dim fdBallots As DataRow()
        fdBallots = ds.Tables("Ballot").Select(strField & "=" & ID)
        'pull the panel for each ballot, find the round based on the panel, and then retrieve all rounds in the same
        'timeslot
        Dim drPanel As DataRow
        Dim drRound As DataRow
        drRound = ds.Tables("Round").Rows.Find(round)
        Dim RoundsInTimeBlock As DataRow()
        RoundsInTimeBlock = ds.Tables("Round").Select("TimeSlot=" & drRound.Item("TimeSlot"))
        'scroll through each ballot, and see if there is one in a round during the current timeslot
        For x = 0 To fdBallots.Length - 1
            drPanel = ds.Tables("Panel").Rows.Find(fdBallots(x).Item("Panel"))
            For y = 0 To RoundsInTimeBlock.Length - 1
                If drPanel.Item("Round") = RoundsInTimeBlock(y).Item("ID") Then ActiveInTimeSlot = True : Exit Function
            Next y
        Next x
    End Function
    Function RoomActiveInTimeSlot(ByVal ds As DataSet, ByVal room As Integer, ByVal round As Integer) As Boolean
        RoomActiveInTimeSLot = False
        Dim fdPanels As DataRow()
        fdPanels = ds.Tables("Panel").Select("Round=" & round & " and Room=" & room)
        If fdPanels.Length > 0 Then RoomActiveInTimeSLot = True
    End Function
    Function SameSchool(ByVal ds As DataSet, ByVal team1 As Integer, ByVal team2 As Integer) As Boolean
        SameSchool = False
        Dim x, y As Integer
        'compare all speakers
        Dim speakers1 As DataRow()
        speakers1 = ds.Tables("Entry_student").Select("Entry=" & team1)
        Dim speakers2 As DataRow()
        speakers2 = ds.Tables("Entry_student").Select("Entry=" & team2)
        For x = 0 To speakers1.Length - 1
            For y = 0 To speakers2.Length - 1
                If speakers1(x).Item("School") = speakers2(y).Item("School") Then SameSchool = True
            Next
        Next x
        'compare teams
        Dim teams As DataRow()
        teams = ds.Tables("Entry").Select("ID=" & team1 & " or ID=" & team2)
        If teams.Length = 1 Then SameSchool = True : Exit Function
        If teams(0).Item("School") = teams(1).Item("school") Then SameSchool = True
    End Function
    Function HitBefore(ByVal ds As DataSet, ByVal team1 As Integer, ByVal team2 As Integer) As Boolean
        'returns true if 2 teams have ever been on the same a panel before
        HitBefore = False
        Dim x, y As Integer
        Dim fdTm1, fdTm2 As DataRow()
        fdTm1 = ds.Tables("Ballot").Select("Entry=" & team1)
        fdTm2 = ds.Tables("Ballot").Select("Entry=" & team2)
        For x = 0 To fdTm1.Length - 1
            For y = 0 To fdTm2.Length - 1
                If fdTm1(x).Item("Panel") = fdTm2(y).Item("Panel") Then HitBefore = True : Exit Function
            Next y
        Next x
    End Function
    Function CanDebate(ByVal ds As DataSet, ByVal team1 As Integer, ByVal team2 As Integer) As String
        CanDebate = ""
        Dim strtime As String = ""
        strtime &= "START: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        If SameSchool(ds, team1, team2) = True Then CanDebate = "CONFLICT! " & GetName(ds.Tables("Entry"), team1, "FullName") & " and " & GetName(ds.Tables("Entry"), team2, "FullName") & " are from the same school."
        strtime &= "Same school done: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        If HitBefore(ds, team1, team2) = True Then CanDebate = "CONFLICT! " & GetName(ds.Tables("Entry"), team1, "FullName") & " have hit " & GetName(ds.Tables("Entry"), team2, "FullName").Trim & " before."
        strtime &= "Hit before done: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        'MsgBox(strtime)
    End Function
    Function CanJudge(ByVal ds As DataSet, ByVal Judge As Integer, ByVal panel As Integer) As Boolean
        CanJudge = True
        'Is judge hearing a round already?
        Dim drPanel, drRound As DataRow
        drPanel = ds.Tables("Panel").Rows.Find(panel)
        drRound = ds.Tables("Round").Rows.Find(drPanel.Item("Round"))
        If ActiveInTimeSlot(ds, Judge, drRound.Item("ID"), "Judge") = True Then CanJudge = False
        'Is the judge from the same school as the team?
        If JudgeSameSchool(ds, Judge, panel) = True Then CanJudge = False
    End Function
    Function JudgeSameSchool(ByVal ds As DataSet, ByVal Judge As Integer, ByVal panel As Integer) As Boolean
        JudgeSameSchool = False
        Dim fdBallot As DataRow()
        fdBallot = ds.Tables("Ballot").Select("Panel=" & panel)
        Dim drJudge, drTeam As DataRow
        drJudge = ds.Tables("Judge").Rows.Find(Judge)
        For x = 0 To fdBallot.Length - 1
            drTeam = ds.Tables("Entry").Rows.Find(fdBallot(x).Item("Entry"))
            If Not drTeam Is Nothing Then
                If drTeam.Item("School") = drJudge.Item("School") Then JudgeSameSchool = True : Exit Function
            End If
        Next x
    End Function
    Function RoundCheck(ByVal ds As DataSet, ByVal round As Integer) As String
        'THIS DOESN'T WORK AS OF YET; it tries to figure out that all teams are scheduled, but even that doesn't work
        RoundCheck = ""
        Exit Function
        'define things
        Dim strAllTeamsScheduled, strAllPanelsFull As String
        Dim fdPanel, fdTeams As DataRow()
        Dim DTDummy As DataTable
        'pull round info; now you know the event and NJudgePerPanel
        Dim drRound As DataRow
        drRound = ds.Tables("Round").Rows.Find(round)
        'CHECK ALL TEAMS ARE SCHEDULED
        strAllTeamsScheduled = ""
        fdTeams = ds.Tables("Entry").Select("Event=" & drRound.Item("Event"))
        For x = 0 To fdTeams.Length - 1
            DTDummy = PullBallotsByRound(ds, "Entry", fdTeams(x).Item("ID"), round)
            If DTDummy.Rows.Count = 0 Then
                strAllTeamsScheduled &= fdTeams(x).Item("FullName") & " not scheduled for round " & drRound.Item("Label") & ". "
            ElseIf DTDummy.Rows.Count > 1 Then
                strAllTeamsScheduled &= fdTeams(x).Item("FullName") & " is scheduled more than once for round " & drRound.Item("Label") & ". "
            End If
        Next x
        'Check all panels have nJudges
        'pull all panels in the round
        strAllPanelsFull = ""
        'fdPanel = ds.Tables("Panel").Select("Round=" & round, "Judge ASC, Panel ASC")
        'For x = 1 To fdPanel.Length - 1
        'If fdPanel(x).Item("Judge") = fdPanel(x - 1).Item("Judge") And fdPanel(x).Item("Panel") <> fdPanel(x - 1).Item("Judge") Then
        'strAllPanelsFull &= fdPanel(x).Item("Judge") & " is scheudled on more than one panel in round " & drRound.Item("Label")
        'End If
        'Next
        If strAllTeamsScheduled = "" Then strAllTeamsScheduled = "All teams are scheduled once and only once."
        RoundCheck = strAllTeamsScheduled
    End Function
    Sub modShowThePairing(ByVal ds As DataSet, ByRef DataGridView1 As DataGridView, ByVal round As Integer)
        'make the results table
        Dim dt As DataTable
        dt = MakeResultsTable(ds, round, "Code")
        Dim foundrow As DataRow
        dt.DefaultView.Sort = "Judge1 ASC"
        'show only name columns, hide the rest
        DataGridView1.DataSource = dt
        For x = DataGridView1.ColumnCount - 1 To 0 Step -1
            If InStr(DataGridView1.Columns(x).Name.ToUpper, "NAME") = 0 Or InStr(DataGridView1.Columns(x).Name.ToUpper, "SPKR") > 0 Then DataGridView1.Columns(x).Visible = False
            If InStr(DataGridView1.Columns(x).Name.ToUpper, "TEAMNAME") > 0 Then
                Dim side As Integer = Val(Mid(DataGridView1.Columns(x).Name, DataGridView1.Columns(x).Name.Length, 1))
                foundrow = ds.Tables("Round").Rows.Find(round)
                DataGridView1.Columns(x).HeaderText = GetSideString(ds, side, foundrow.Item("Event"))
            End If
        Next
    End Sub
    Function SideCheck(ByVal ds As DataSet, ByVal team As Integer, ByVal side As Integer, ByVal round As Integer, ByVal SidesSoFar As String) As String
        SideCheck = ""
        'get values you'll need
        Dim drRound As DataRow : drRound = ds.Tables("Round").Rows.Find(round)
        Dim nPrelims As Integer = getEventSetting(ds, drRound.Item("Event"), "nPrelims")
        Dim nSides As Integer
        If getEventSetting(ds, drRound.Item("Event"), "SideDesignations") = "Aff/Neg" Then nSides = 2
        If getEventSetting(ds, drRound.Item("Event"), "SideDesignations") = "Gov/Opp" Then nSides = 2
        If getEventSetting(ds, drRound.Item("Event"), "SideDesignations") = "WUDC" Then nSides = 4
        Dim SidesByRd(SidesSoFar.Length) As Integer
        For x = 1 To SidesSoFar.Length
            SidesByRd(x) = Val(Mid(SidesSoFar, x, 1))
        Next x
        'UNIT comparison; if there are 2 side designations, for example, compare in 2-round units
        'Find the last unit to compare
        Dim st, ctr As Integer
        For x = 1 To nPrelims Step nSides
            If x <= SidesSoFar.Length Then st = x
        Next x
        'mark the sides they've already been in that unit
        Dim SideIn(nSides) As Integer
        For x = st To SidesSoFar.Length
            SideIn(SidesByRd(x)) += 1
        Next x
        ctr = 0
        If SideIn(side) > 0 Then
            SideCheck &= " WARNING: This team has already been " & GetSideString(ds, side, drRound.Item("Event")) & " since round " & st.ToString & ".  Typically, they would need to be"
            For x = 1 To nSides
                If ctr > 0 Then SideCheck &= " or"
                If SideIn(x) = 0 Then SideCheck &= " " & GetSideString(ds, x, drRound.Item("Event")) : ctr += 1
            Next x
            SideCheck &= " before they are " & GetSideString(ds, side, drRound.Item("Event")) & " again."
        End If
        'TOTAL COUNT comparison
        'reset and count total number of times on each side
        For x = 0 To nSides : SideIn(x) = 0 : Next x
        For x = 1 To SidesSoFar.Length : SideIn(SidesByRd(x)) += 1 : Next x
        'figure out the minimum number of times a team needs to be on each side, and count the remaining rounds
        Dim nTimes As Integer
        nTimes = Int(nPrelims / nPrelims)
        Dim RdsLeft As Integer = nPrelims - SidesSoFar.Length
        'show the message if aren't enough rounds left to get enough rounds on each side in
        For x = 1 To nSides
            If RdsLeft <= nTimes - SideIn(x) And side <> x Then
                SideCheck &= " WARNING: This team MUST be " & GetSideString(ds, x, drRound.Item("Event")) & " in this round to have enough " & GetSideString(ds, x, drRound.Item("Event")) & " rounds for the prelims."
            End If
        Next x
    End Function
    Public Function GetSideDue(ByVal ds As DataSet, ByVal round As Integer, ByVal team As Integer) As Integer
        GetSideDue = 0
        'pull side team was last round, and flip it
        'find all panels in round, pick the one that has the team in it and is the round before the current round
        Dim fdBallots As DataRow()
        Dim fdPanel As DataRow
        fdBallots = ds.Tables("Ballot").Select("Entry=" & team)
        For x = 0 To fdBallots.Length - 1
            fdPanel = ds.Tables("Panel").Rows.Find(fdBallots(x).Item("Panel"))
            If fdPanel.Item("Round") = GetPriorRound(ds, round) Then
                If fdBallots(x).Item("Side") = 1 Then GetSideDue = 2 : Exit Function
                If fdBallots(x).Item("Side") = 2 Then GetSideDue = 1 : Exit Function
            End If
        Next x
    End Function
    Function MakeRoomStatusTable(ByVal ds As DataSet) As DataTable
        'Shows prelim room status

        Dim dt As New DataTable
        dt.Columns.Add("Slot", System.Type.GetType("System.String"))
        dt.Columns.Add("Event", System.Type.GetType("System.String"))
        dt.Columns.Add("Need", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Have", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Balance", System.Type.GetType("System.Int16"))

        Dim dr As DataRow
        Dim ShowSlot As Boolean
        Dim fdRds, fdTeams, fdRooms As DataRow()
        Dim z, ctr As Integer
        For y = 0 To ds.Tables("Timeslot").Rows.Count - 1
            ShowSlot = False
            fdRds = ds.Tables("Round").Select("Timeslot=" & ds.Tables("Timeslot").Rows(y).Item("ID"))
            For x = 0 To fdRds.Length - 1
                If fdRds(x).Item("Rd_Name") <= 9 Then ShowSlot = True : Exit For
            Next
            If ShowSlot = True Then
                ctr = 0
                For x = 0 To ds.Tables("Event").Rows.Count - 1
                    dr = dt.NewRow
                    dr.Item("Slot") = ds.Tables("Timeslot").Rows(y).Item("Name").trim
                    dr.Item("Event") = ds.Tables("Event").Rows(x).Item("Abbr")
                    fdTeams = ds.Tables("Entry").Select("Event=" & ds.Tables("event").Rows(x).Item("ID"))
                    dr.Item("Need") = Int(fdTeams.Length / getEventSetting(ds, ds.Tables("event").Rows(x).Item("ID"), "TeamsPerRound"))
                    dr.Item("Have") = 0
                    fdRooms = ds.Tables("Room").Select("Inactive=false and " & "TimeSlot" & ds.Tables("TimeSlot").Rows(y).Item("ID") & "=true and " & "Event" & ds.Tables("Event").Rows(x).Item("ID") & "=true")
                    dr.Item("Have") = fdRooms.Length
                    dr.Item("Balance") = dr.Item("Have") - dr.Item("Need")
                    dt.Rows.Add(dr)
                    ctr += dr.Item("Need")
                Next x
        'add totals row
        dr = dt.NewRow
        dr.Item("Slot") = ds.Tables("Timeslot").Rows(y).Item("Name").trim
        dr.Item("Event") = "ALL"
        dr.Item("Need") = ctr
        dr.Item("Have") = 0
        For z = 0 To ds.Tables("Room").Rows.Count - 1
            If ds.Tables("Room").Rows(z).Item("Inactive") <> True And ds.Tables("Room").Rows(z).Item("TimeSlot" & ds.Tables("TimeSlot").Rows(y).Item("ID")) = True Then dr.Item("Have") += 1
        Next z
        dr.Item("Balance") = dr.Item("Have") - dr.Item("Need")
        dt.Rows.Add(dr)
            End If
        Next y

        Return dt

    End Function
    Sub AddSideReport(ByRef dt As DataTable, ByVal ds As DataSet)
        Dim strDummy As String
        Dim fdBallot As DataRow()
        Dim drPanel, drRound As DataRow
        For x = 0 To dt.Rows.Count - 1
            fdBallot = ds.Tables("Ballot").Select("Entry=" & dt.Rows(x).Item("Competitor"), "Panel ASC")
            strDummy = ""
            For y = 0 To fdBallot.Length - 1
                drPanel = ds.Tables("Panel").Rows.Find(fdBallot(y).Item("Panel"))
                drRound = ds.Tables("Round").Rows.Find(drPanel.Item("Round"))
                If drRound.Item("RD_NAME") <= 9 Then
                    If y = 0 Then
                        strDummy = fdBallot(y).Item("Side")
                    ElseIf fdBallot(y).Item("Panel") <> fdBallot(y - 1).Item("Panel") Then
                        strDummy &= fdBallot(y).Item("Side")
                    End If
                End If
            Next y
            dt.Rows(x).Item("Sides") = strDummy
        Next x
    End Sub
End Module
