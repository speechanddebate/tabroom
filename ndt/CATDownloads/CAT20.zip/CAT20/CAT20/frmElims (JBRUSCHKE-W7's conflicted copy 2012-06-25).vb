﻿Public Class frmElims
    Dim ds As New DataSet
    Private Sub frmElims_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call LoadFile(ds, "TourneyData")
        cboDivisions.DataSource = ds.Tables("Event")
        cboDivisions.DisplayMember = "EventName"
        cboDivisions.ValueMember = "ID"
    End Sub
    Private Sub frmElims_Unload(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
        Call SaveFile(ds)
        ds.Dispose()
    End Sub

    Private Sub butLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butLoad.Click
        'pull all elim rounds for the division
        Dim fdElimRds As DataRow()
        fdElimRds = ds.Tables("Round").Select("Event=" & cboDivisions.SelectedValue & " and Rd_Name >9", "Rd_Name asc")
        'make table
        Dim dt As New DataTable
        DataGridView1.AutoGenerateColumns = False
        For x = 0 To fdElimRds.Length - 1
            dt.Columns.Add("Panel" & x + 1, System.Type.GetType("System.Int64"))
            dt.Columns.Add(fdElimRds(x).Item("Label"), System.Type.GetType("System.String"))
            Dim dgvc As New DataGridViewTextBoxColumn
            dgvc.DataPropertyName = "Panel" & x + 1.ToString
            dgvc.Visible = False
            DataGridView1.Columns.Add(dgvc)
            dgvc = New DataGridViewTextBoxColumn
            dgvc.DataPropertyName = fdElimRds(x).Item("Label")
            dgvc.HeaderText = fdElimRds(x).Item("Label")
            DataGridView1.Columns.Add(dgvc)
        Next x
        'populate the table
        Dim fdElimPanels, fdElimSeeds, fdElimBallots As DataRow()
        Dim dr As DataRow
        Dim ctr As Integer
        For x = 0 To fdElimRds.Length - 1
            ctr = 0
            'pull the panels and seeds in the round
            fdElimPanels = ds.Tables("Panel").Select("Round=" & fdElimRds(x).Item("ID"))
            fdElimSeeds = ds.Tables("ElimSeed").Select("Round=" & fdElimRds(x).Item("ID"), "Seed ASC")
            For y = 0 To fdElimPanels.Length - 1
                'pull all the ballots in the round
                fdElimBallots = ds.Tables("Ballot").Select("Panel=" & fdElimPanels(y).Item("ID"))
                'sort ballots by seed order
                For z = 0 To (fdElimSeeds.Length / 2) - 1
                    For w = 0 To fdElimBallots.Length - 1
                        If fdElimBallots(w).Item("Entry") = fdElimSeeds(z).Item("Entry") Then
                            If x = 0 Then
                                dr = dt.NewRow
                                dr.Item("Panel" & x + 1.ToString) = fdElimBallots(w).Item("Panel")
                                dr.Item(fdElimRds(x).Item("Label")) = MakeTeamString(fdElimPanels(y).Item("Round"), fdElimSeeds(z).Item("seed"), fdElimBallots(w).Item("Panel"))
                                dt.Rows.Add(dr)
                                Exit For
                            Else
                                dt.Rows(ctr).Item("Panel" & x + 1.ToString) = fdElimBallots(w).Item("Panel")
                                dt.Rows(ctr).Item(fdElimRds(x).Item("Label")) = MakeTeamString(fdElimPanels(y).Item("Round"), fdElimSeeds(z).Item("seed"), fdElimBallots(w).Item("Panel"))
                                ctr += 1
                                Exit For
                            End If
                        End If
                    Next w
                Next z
            Next y
        Next x
        DataGridView1.DataSource = dt
        DataGridView1.DefaultCellStyle.Font = New Font("Arial", 9, FontStyle.Bold, GraphicsUnit.Point)
        If dt.Rows.Count > 20 Then DataGridView1.DefaultCellStyle.Font = New Font("Arial", 8, FontStyle.Bold, GraphicsUnit.Point)
    End Sub
    Function MakeTeamString(ByVal round As Integer, ByVal seed As Integer, ByVal panel As Integer) As String
        Dim team1, team2 As Integer
        'pull all the ballots
        Dim fdballot As DataRow()
        fdballot = ds.Tables("Ballot").Select("Panel=" & panel)
        'calculate second seed
        Dim seed2 As Integer
        Dim fdDebates As DataRow()
        fdDebates = ds.Tables("Panel").Select("Round=" & round)
        seed2 = ((fdDebates.Length * 2) - seed) + 1
        'find the teams
        For x = 0 To ds.Tables("ElimSeed").Rows.Count - 1
            If ds.Tables("ElimSeed").Rows(x).Item("Seed") = seed And ds.Tables("ElimSeed").Rows(x).Item("Round") = round Then
                If fdballot(0).Item("Entry") = ds.Tables("ElimSeed").Rows(x).Item("Entry") Then
                    team1 = fdballot(0).Item("Entry")
                    team2 = fdballot(1).Item("Entry")
                End If
                If fdballot(1).Item("Entry") = ds.Tables("ElimSeed").Rows(x).Item("Entry") Then
                    team1 = fdballot(1).Item("Entry")
                    team2 = fdballot(0).Item("Entry")
                End If
            End If
        Next
        'build the string
        Dim dr As DataRow
        MakeTeamString = "(" & seed.ToString & ") "
        dr = ds.Tables("Entry").Rows.Find(team1)
        MakeTeamString &= dr.Item("Code").trim
        MakeTeamString &= " (" & seed2.ToString & ") "
        dr = ds.Tables("Entry").Rows.Find(team2)
        MakeTeamString &= dr.Item("Code").trim
    End Function
    Sub CellClick() Handles DataGridView1.CellClick
        Dim panel As Integer
        Try
            panel = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(DataGridView1.CurrentCell.ColumnIndex - 1).Value
        Catch
            Exit Sub
        End Try

        Dim TeamsPerRd As Integer = GetTagValue(ds.Tables("Event_Setting"), "TeamsPerRound")

        Dim dt As New DataTable
        dt.Columns.Add("JudgeID", System.Type.GetType("System.Int64"))
        dt.Columns.Add("Judge", System.Type.GetType("System.String"))
        For x = 0 To TeamsPerRd - 1
            dt.Columns.Add("TeamID" & x + 1, System.Type.GetType("System.Int64"))
            dt.Columns.Add("Team" & x + 1, System.Type.GetType("System.String"))
        Next x

        'pull all the ballots for the panel, sort by judge
        Dim fdBallots As DataRow()
        fdBallots = ds.Tables("Ballot").Select("Panel=" & Panel, "Judge asc, Entry asc")
        Dim dr As DataRow : Dim ctr As Integer = 1
        For x = 0 To fdBallots.Length - 1
            If x < fdBallots.Length - 1 Then
                If fdBallots(x).Item("Judge") <> fdBallots(x + 1).Item("Judge") Then
                    dr = dt.NewRow
                    dr.Item("JudgeID") = fdBallots(x).Item("Judge")
                    dr.Item("Judge") = GetName(ds.Tables("Judge"), fdBallots(x).Item("Judge"), "Last") & ", " & GetName(ds.Tables("Judge"), fdBallots(x).Item("Judge"), "First")
                    Call ballotIn(dr, fdBallots(x).Item("Judge"), Panel)
                    dt.Rows.Add(dr)
                End If
            Else
                dr = dt.NewRow
                dr.Item("JudgeID") = fdBallots(x).Item("Judge")
                dr.Item("Judge") = GetName(ds.Tables("Judge"), fdBallots(x).Item("Judge"), "Last") & ", " & GetName(ds.Tables("Judge"), fdBallots(x).Item("Judge"), "First")
                Call ballotIn(dr, fdBallots(x).Item("Judge"), Panel)
                dt.Rows.Add(dr)
            End If
        Next x
        DataGridView2.DataSource = dt
        'suppress ID columns
        For x = 0 To DataGridView2.ColumnCount - 1
            If DataGridView2.Columns(x).Name = "JudgeID" Then DataGridView2.Columns(x).Visible = False
            If Mid(DataGridView2.Columns(x).Name, 1, 6) = "TeamID" Then
                DataGridView2.Columns(x).Visible = False
                DataGridView2.Columns(x + 1).HeaderText = FullNameMaker(ds, DataGridView2.Rows(1).Cells(x).Value, "CODE", 1)
            End If
        Next x

    End Sub
    Sub ballotIn(ByRef dr As DataRow, ByVal judge As Integer, ByVal panel As Integer)
        'pull all ballots by judge
        Dim fdBallots, fdScore As DataRow()
        fdBallots = ds.Tables("Ballot").Select("Panel=" & panel & " and judge=" & judge, "Entry ASC")
        For x = 0 To fdBallots.Length - 1
            'pull the ballot_score and store it in the team column
            dr.Item("TeamID" & x + 1) = fdBallots(x).Item("Entry")
            fdScore = ds.Tables("Ballot_Score").Select("Ballot=" & fdBallots(x).Item("ID") & " and Recipient=" & fdBallots(x).Item("Entry") & " and Score_ID=1")
            dr.Item("Team" & x + 1) = fdScore(0).Item("Score")
        Next x
    End Sub
End Class