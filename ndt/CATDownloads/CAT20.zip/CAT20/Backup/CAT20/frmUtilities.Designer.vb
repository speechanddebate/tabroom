﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUtilities
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.butUDSImport = New System.Windows.Forms.Button
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Button3 = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Button4 = New System.Windows.Forms.Button
        Me.butDeleteResults = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button10 = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Button11 = New System.Windows.Forms.Button
        Me.Button12 = New System.Windows.Forms.Button
        Me.Button13 = New System.Windows.Forms.Button
        Me.Button14 = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.butEraseResults = New System.Windows.Forms.Button
        Me.butDeleteRound = New System.Windows.Forms.Button
        Me.cboRound = New System.Windows.Forms.ComboBox
        Me.Button15 = New System.Windows.Forms.Button
        Me.Button16 = New System.Windows.Forms.Button
        Me.butBackUp = New System.Windows.Forms.Button
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.Button17 = New System.Windows.Forms.Button
        Me.butBallotClean = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Button20 = New System.Windows.Forms.Button
        Me.butNames = New System.Windows.Forms.Button
        Me.butKillNulls = New System.Windows.Forms.Button
        Me.Button18 = New System.Windows.Forms.Button
        Me.Button19 = New System.Windows.Forms.Button
        Me.Button21 = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.butTimeSLotLoad = New System.Windows.Forms.Button
        Me.butTSMatch = New System.Windows.Forms.Button
        Me.butRoundMatch = New System.Windows.Forms.Button
        Me.butRoundLoad = New System.Windows.Forms.Button
        Me.Button22 = New System.Windows.Forms.Button
        Me.butTBFix = New System.Windows.Forms.Button
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'butUDSImport
        '
        Me.butUDSImport.Location = New System.Drawing.Point(953, 8)
        Me.butUDSImport.Name = "butUDSImport"
        Me.butUDSImport.Size = New System.Drawing.Size(167, 87)
        Me.butUDSImport.TabIndex = 0
        Me.butUDSImport.Text = "Import file using the Universal Data Structure"
        Me.butUDSImport.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(204, 224)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(87, 28)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "POST test"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(11, 188)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(107, 30)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Post FILE test"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(293, 320)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Label1"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(6, 123)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(232, 25)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Post FILE test method 2"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(358, 149)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(887, 126)
        Me.TextBox1.TabIndex = 5
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(103, 83)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(106, 29)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "Zip it"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'butDeleteResults
        '
        Me.butDeleteResults.Location = New System.Drawing.Point(1138, 8)
        Me.butDeleteResults.Name = "butDeleteResults"
        Me.butDeleteResults.Size = New System.Drawing.Size(114, 87)
        Me.butDeleteResults.TabIndex = 7
        Me.butDeleteResults.Text = "Delete all pairings and results"
        Me.butDeleteResults.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(124, 188)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(121, 30)
        Me.Button5.TabIndex = 8
        Me.Button5.Text = "Get tourney list"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(6, 154)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(227, 28)
        Me.Button6.TabIndex = 9
        Me.Button6.Text = "Download initial files"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(216, 54)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 10
        Me.Button7.Text = "Button7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(6, 51)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(209, 26)
        Me.Button8.TabIndex = 11
        Me.Button8.Text = "Reset createdoffline values"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(215, 83)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(96, 40)
        Me.Button9.TabIndex = 12
        Me.Button9.Text = "Load Gonz names"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(15, 258)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(147, 25)
        Me.Button10.TabIndex = 13
        Me.Button10.Text = "Synch Gonz email"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(358, 309)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(887, 264)
        Me.DataGridView1.TabIndex = 14
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(690, 114)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(140, 29)
        Me.Button11.TabIndex = 15
        Me.Button11.Text = "judges to grid"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(15, 289)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(118, 34)
        Me.Button12.TabIndex = 16
        Me.Button12.Text = "timeslot reset"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(6, 23)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(75, 23)
        Me.Button13.TabIndex = 17
        Me.Button13.Text = "student check"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(6, 83)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(97, 34)
        Me.Button14.TabIndex = 18
        Me.Button14.Text = "JudgesFix"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.butEraseResults)
        Me.GroupBox1.Controls.Add(Me.butDeleteRound)
        Me.GroupBox1.Controls.Add(Me.cboRound)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 121)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(275, 172)
        Me.GroupBox1.TabIndex = 19
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Erase round info"
        '
        'butEraseResults
        '
        Me.butEraseResults.Location = New System.Drawing.Point(16, 112)
        Me.butEraseResults.Name = "butEraseResults"
        Me.butEraseResults.Size = New System.Drawing.Size(248, 28)
        Me.butEraseResults.TabIndex = 2
        Me.butEraseResults.Text = "Clear Results for selected round"
        Me.butEraseResults.UseVisualStyleBackColor = True
        '
        'butDeleteRound
        '
        Me.butDeleteRound.Location = New System.Drawing.Point(16, 78)
        Me.butDeleteRound.Name = "butDeleteRound"
        Me.butDeleteRound.Size = New System.Drawing.Size(248, 28)
        Me.butDeleteRound.TabIndex = 1
        Me.butDeleteRound.Text = "Delete entire round"
        Me.butDeleteRound.UseVisualStyleBackColor = True
        '
        'cboRound
        '
        Me.cboRound.FormattingEnabled = True
        Me.cboRound.Location = New System.Drawing.Point(7, 34)
        Me.cboRound.Name = "cboRound"
        Me.cboRound.Size = New System.Drawing.Size(186, 28)
        Me.cboRound.TabIndex = 0
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(87, 23)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(158, 29)
        Me.Button15.TabIndex = 20
        Me.Button15.Text = "delete non-active prefs"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(11, 224)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(181, 28)
        Me.Button16.TabIndex = 21
        Me.Button16.Text = "Convert text to pairings"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'butBackUp
        '
        Me.butBackUp.Location = New System.Drawing.Point(12, 8)
        Me.butBackUp.Name = "butBackUp"
        Me.butBackUp.Size = New System.Drawing.Size(118, 67)
        Me.butBackUp.TabIndex = 22
        Me.butBackUp.Text = "Back Up"
        Me.butBackUp.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(171, 258)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(127, 24)
        Me.Button17.TabIndex = 23
        Me.Button17.Text = "Reset Password"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'butBallotClean
        '
        Me.butBallotClean.Location = New System.Drawing.Point(239, 124)
        Me.butBallotClean.Name = "butBallotClean"
        Me.butBallotClean.Size = New System.Drawing.Size(75, 58)
        Me.butBallotClean.TabIndex = 24
        Me.butBallotClean.Text = "Clean up ballots"
        Me.butBallotClean.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Button20)
        Me.GroupBox2.Controls.Add(Me.butNames)
        Me.GroupBox2.Controls.Add(Me.butKillNulls)
        Me.GroupBox2.Controls.Add(Me.Button13)
        Me.GroupBox2.Controls.Add(Me.Button18)
        Me.GroupBox2.Controls.Add(Me.Button8)
        Me.GroupBox2.Controls.Add(Me.Button17)
        Me.GroupBox2.Controls.Add(Me.butBallotClean)
        Me.GroupBox2.Controls.Add(Me.Button15)
        Me.GroupBox2.Controls.Add(Me.Button14)
        Me.GroupBox2.Controls.Add(Me.Button16)
        Me.GroupBox2.Controls.Add(Me.Button12)
        Me.GroupBox2.Controls.Add(Me.Button4)
        Me.GroupBox2.Controls.Add(Me.Button3)
        Me.GroupBox2.Controls.Add(Me.Button6)
        Me.GroupBox2.Controls.Add(Me.Button10)
        Me.GroupBox2.Controls.Add(Me.Button7)
        Me.GroupBox2.Controls.Add(Me.Button9)
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Controls.Add(Me.Button5)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 343)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(334, 407)
        Me.GroupBox2.TabIndex = 25
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "All the ugly options"
        Me.GroupBox2.Visible = False
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(236, 324)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(75, 23)
        Me.Button20.TabIndex = 28
        Me.Button20.Text = "Random"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'butNames
        '
        Me.butNames.Location = New System.Drawing.Point(204, 350)
        Me.butNames.Name = "butNames"
        Me.butNames.Size = New System.Drawing.Size(111, 51)
        Me.butNames.TabIndex = 27
        Me.butNames.Text = "Name Muncher"
        Me.butNames.UseVisualStyleBackColor = True
        '
        'butKillNulls
        '
        Me.butKillNulls.Location = New System.Drawing.Point(15, 329)
        Me.butKillNulls.Name = "butKillNulls"
        Me.butKillNulls.Size = New System.Drawing.Size(170, 67)
        Me.butKillNulls.TabIndex = 26
        Me.butKillNulls.Text = "Convert all null values in the datafile to zero"
        Me.butKillNulls.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(154, 290)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(157, 33)
        Me.Button18.TabIndex = 26
        Me.Button18.Text = "Delete elim panels"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(12, 309)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(201, 28)
        Me.Button19.TabIndex = 27
        Me.Button19.Text = "Show the full option box"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(1135, 101)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(117, 28)
        Me.Button21.TabIndex = 28
        Me.Button21.Text = "Fix All Nulls"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.butTimeSLotLoad)
        Me.GroupBox3.Controls.Add(Me.butTSMatch)
        Me.GroupBox3.Controls.Add(Me.butRoundMatch)
        Me.GroupBox3.Controls.Add(Me.butRoundLoad)
        Me.GroupBox3.Location = New System.Drawing.Point(358, 13)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(314, 100)
        Me.GroupBox3.TabIndex = 29
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "online matcher"
        Me.GroupBox3.Visible = False
        '
        'butTimeSLotLoad
        '
        Me.butTimeSLotLoad.Location = New System.Drawing.Point(6, 54)
        Me.butTimeSLotLoad.Name = "butTimeSLotLoad"
        Me.butTimeSLotLoad.Size = New System.Drawing.Size(119, 28)
        Me.butTimeSLotLoad.TabIndex = 4
        Me.butTimeSLotLoad.Text = "Timeslot Load"
        Me.butTimeSLotLoad.UseVisualStyleBackColor = True
        '
        'butTSMatch
        '
        Me.butTSMatch.Location = New System.Drawing.Point(176, 54)
        Me.butTSMatch.Name = "butTSMatch"
        Me.butTSMatch.Size = New System.Drawing.Size(117, 28)
        Me.butTSMatch.TabIndex = 3
        Me.butTSMatch.Text = "Timeslot Match"
        Me.butTSMatch.UseVisualStyleBackColor = True
        '
        'butRoundMatch
        '
        Me.butRoundMatch.Location = New System.Drawing.Point(176, 20)
        Me.butRoundMatch.Name = "butRoundMatch"
        Me.butRoundMatch.Size = New System.Drawing.Size(117, 28)
        Me.butRoundMatch.TabIndex = 2
        Me.butRoundMatch.Text = "Round match"
        Me.butRoundMatch.UseVisualStyleBackColor = True
        '
        'butRoundLoad
        '
        Me.butRoundLoad.Location = New System.Drawing.Point(6, 20)
        Me.butRoundLoad.Name = "butRoundLoad"
        Me.butRoundLoad.Size = New System.Drawing.Size(102, 28)
        Me.butRoundLoad.TabIndex = 0
        Me.butRoundLoad.Text = "Round Load"
        Me.butRoundLoad.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(690, 58)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(140, 50)
        Me.Button22.TabIndex = 30
        Me.Button22.Text = "Set max judge commitment"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'butTBFix
        '
        Me.butTBFix.Location = New System.Drawing.Point(147, 64)
        Me.butTBFix.Name = "butTBFix"
        Me.butTBFix.Size = New System.Drawing.Size(140, 51)
        Me.butTBFix.TabIndex = 31
        Me.butTBFix.Text = "Magic Tiebreaker Fixit Button"
        Me.butTBFix.UseVisualStyleBackColor = True
        '
        'frmUtilities
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 762)
        Me.Controls.Add(Me.butTBFix)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.butBackUp)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.butDeleteResults)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.butUDSImport)
        Me.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmUtilities"
        Me.Text = "Utilites"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents butUDSImport As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents butDeleteResults As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents butEraseResults As System.Windows.Forms.Button
    Friend WithEvents butDeleteRound As System.Windows.Forms.Button
    Friend WithEvents cboRound As System.Windows.Forms.ComboBox
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents butBackUp As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents butBallotClean As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents butNames As System.Windows.Forms.Button
    Friend WithEvents butKillNulls As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents butTSMatch As System.Windows.Forms.Button
    Friend WithEvents butRoundMatch As System.Windows.Forms.Button
    Friend WithEvents butRoundLoad As System.Windows.Forms.Button
    Friend WithEvents butTimeSLotLoad As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents butTBFix As System.Windows.Forms.Button
End Class
